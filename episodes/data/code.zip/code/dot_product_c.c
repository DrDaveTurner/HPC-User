#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

double myclock();

void main (int argc, char **argv)
{
   int i, N;
   double dprod, *X, *Y;
   double t_start, t_elapsed;
   char outfile[20];
   FILE *fd;

   N = 100000000;

      // Allocate space for the X and Y vectors

   X = malloc( N * sizeof(double) );
   Y = malloc( N * sizeof(double) );

      // Initialize the X and Y vectors

   for( i = 0; i < N; i++ ) {
      X[i] = (double) i;
      Y[i] = (double) i;
   }

      // Allocate and innitialize a dummy array to clear cache

   double *dummy = malloc( 125000000 * sizeof(double) );
   for( i = 0; i < 125000000; i++ ) { dummy[i] = 0.0; }


      // Now we start the timer and do our calculation

t_start = myclock();

   dprod = 0.0;
   for( i = 0; i < N; i++ ) {
      dprod += X[i] * Y[i];
   }

t_elapsed = myclock() - t_start;

   printf("dot product = %lf  took %lf seconds\n", dprod, t_elapsed );
   printf("%lf Gflops (billion floating-point operations per second)\n",
          2.0*N*1.0e-9 / t_elapsed);
   printf( "%lf GB memory used\n", 2.0*N*8.0/1.0e9);

}

double myclock() {
   static time_t t_start = 0;  // Save and subtract off each time

   struct timespec ts;
   clock_gettime(CLOCK_REALTIME, &ts);
   if( t_start == 0 ) t_start = ts.tv_sec;

   return (double) (ts.tv_sec - t_start) + ts.tv_nsec * 1.0e-9;
}
