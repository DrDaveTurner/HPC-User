# Matrix multiply using parallel foreach loops in R
# USAGE:  Rscript matmult_foreach.R 1000 4        for a 1000x1000 matrix size on 4 cores
# NOTE: This works for single core only.  No shared memory writes for multi-core.
#       bigmemory package and jumping through lots of hoops would probably work.

# All numbers are double precision 64-bit in R

#library( foreach )
library( doParallel )


   # Get the matrix size from the command line

args <- commandArgs(TRUE)
n <- as.integer( args[1] )


   # Set the number of cores to use

ncores <- detectCores()
print( paste( ncores, "cores detected by detectCores()" ) )
ncores <- getDoParWorkers()
print( paste( ncores, "cores detected by getDoParWorkers()" ) )

ncores <- as.integer( args[2] )
registerDoParallel( ncores )


   # Start by allocating space for all 3 matrices

a <- matrix( 1:n*n, ncol = n, nrow = n )
b <- matrix( 1:n*n, ncol = n, nrow = n )
c <- matrix( 1:n*n, ncol = n, nrow = n )

   # Now initialize the a and b matrices and zero the c matrix

#df <- foreach( i = 1:n ) %dopar%
for( i in 1:n )
{
   for( j in 1:n )
   {
      a[i,j] <- as.double(j+1) / as.double(i+1)
      b[i,j] <- as.double(j+1) / as.double(i+1)
      c[i,j] <- 0.0
   }
}


# Clear the cache buffers before timing

dummy <- matrix( 1:125000000 )       # 1 GB of data to flush caches


   # Time the matrix multiplication using multi-threaded foreach loops

t_start = proc.time()[[3]]

   #df <- foreach( i = 1:n ) %dopar%
   df <- foreach( i = 1:n ) %dopar%
   {
      for( j in 1:n )
      {
         for( k in 1:n )
         {
            c[i,j] <- c[i,j] + a[i,k] * b[k,j]
         }
      }
   }

print( paste( "Foreach mat mult size ", n, "on ", ncores, "cores took ", proc.time()[[3]]-t_start, "seconds") )
write.table( c, file="matrix-foreach.csv", row.names=FALSE, col.names=FALSE, sep = ',')


